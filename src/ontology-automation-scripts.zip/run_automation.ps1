$ErrorActionPreference = "Stop"

$ProjectDir = Split-Path -Parent $PSScriptRoot
$Python = Join-Path $ProjectDir ".venv\Scripts\python.exe"

if (-not (Test-Path $Python)) {
    throw "没有找到虚拟环境：$Python。请先在项目根目录执行 python -m venv .venv"
}

Write-Host "[1/2] 重新生成具有唯一Ontology IRI的基准集……" -ForegroundColor Cyan
& $Python (Join-Path $PSScriptRoot "inject_errors.py")
if ($LASTEXITCODE -ne 0) {
    throw "inject_errors.py 执行失败，退出码：$LASTEXITCODE"
}

Write-Host "`n[2/2] 批量运行Reasoner、证据校验和CQ回归……" -ForegroundColor Cyan
& $Python (Join-Path $PSScriptRoot "validate_benchmark.py")
if ($LASTEXITCODE -ne 0) {
    throw "validate_benchmark.py 执行失败，退出码：$LASTEXITCODE"
}

Write-Host "`n自动化实验全部完成。结果位于：$ProjectDir\output" -ForegroundColor Green
