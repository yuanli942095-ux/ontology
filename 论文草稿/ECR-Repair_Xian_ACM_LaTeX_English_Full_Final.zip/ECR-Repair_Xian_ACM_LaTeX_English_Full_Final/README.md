# ECR-Repair Full English Manuscript

This package is the full English version of the latest narrative-enhanced ECR-Repair ACM-style manuscript.

## Main files
- `main.tex` - full English LaTeX source
- `main.pdf` - compiled 16-page English manuscript
- `references.bib` - bibliography database
- `main.bbl` - compiled bibliography content for environments without BibTeX
- `figures/` - English figures used by the manuscript

## Compilation
Recommended sequence:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If BibTeX is unavailable, the included `main.bbl` can be used with repeated `pdflatex` runs.

## Validation
- Full manuscript text is English; no Chinese CJK characters remain in `main.tex` or extracted PDF text.
- LaTeX compilation completed with no fatal errors and no undefined citations/references.
- `Overfull \\hbox`: 0 in the final build.
- The final PDF was rendered page-by-page for visual inspection.
