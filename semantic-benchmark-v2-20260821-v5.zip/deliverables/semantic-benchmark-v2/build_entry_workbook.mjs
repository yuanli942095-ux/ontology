import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const artifactRoot = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
if (!artifactRoot) {
  throw new Error("CODEX_PRIMARY_RUNTIME_NODE_MODULES is not set");
}
const artifactModule = await import(pathToFileURL(
  path.join(artifactRoot, "@oai/artifact-tool/dist/artifact_tool.mjs")
).href);
const { SpreadsheetFile, Workbook } = artifactModule;

const root = path.resolve("deliverables/semantic-benchmark-v2");
const eventPath = path.join(root, "benchmark/semantic-v2/input/semantic-event-template.csv");
const documentPath = path.join(root, "benchmark/semantic-v2/input/semantic-document-template.csv");
const candidatePath = path.join(root, "benchmark/semantic-v2/input/semantic-candidate-template.csv");
const oraclePath = path.join(root, "benchmark/semantic-v2/private/semantic-oracle-template.csv");
const outputPath = path.join(root, "semantic-benchmark-v2-录入模板.xlsx");
const previewDir = path.join(root, "preview");

const [eventCsv, documentCsv, candidateCsv, oracleCsv] = await Promise.all([
  fs.readFile(eventPath, "utf8"),
  fs.readFile(documentPath, "utf8"),
  fs.readFile(candidatePath, "utf8"),
  fs.readFile(oraclePath, "utf8"),
]);

const workbook = await Workbook.fromCSV(eventCsv, { sheetName: "Events" });
await workbook.fromCSV(documentCsv, { sheetName: "Documents" });
await workbook.fromCSV(candidateCsv, { sheetName: "Candidates" });
await workbook.fromCSV(oracleCsv, { sheetName: "Oracle_PRIVATE" });

const dictionary = workbook.worksheets.add("DataDictionary");
dictionary.getRange("A1:F1").values = [[
  "Sheet", "Field", "Required when READY", "Allowed values / format", "Meaning", "Confidentiality"
]];
const dictionaryRows = [
  ["Events", "event_id", "Yes", "E12—E41; unique", "Stable event identifier", "Public"],
  ["Events", "split", "Yes", "dev | test", "2 dev and 8 test cases per semantic type", "Public"],
  ["Events", "semantic_type", "Yes", "TEMPORAL_VERSION | GENERAL_RULE_EXCEPTION | CROSS_SENTENCE_SCOPE", "Independent semantic challenge type", "Public"],
  ["Events", "case_context", "Yes", "Natural-language facts; no answer hint", "Facts needed to decide applicability", "Public"],
  ["Events", "document_ids", "Yes", "DOC IDs separated by |", "Documents visible to the model", "Public"],
  ["Events", "source_owl", "Yes", "Project-relative OWL path", "Mutant ontology before repair", "Public"],
  ["Documents", "authority", "Yes", "Integer; higher means more authoritative", "Document authority used by baselines", "Public"],
  ["Documents", "effective_from/to", "Yes", "YYYY-MM-DD; end may be blank", "Validity interval", "Public"],
  ["Documents", "sha256", "Yes", "64 hex chars", "File integrity hash", "Public"],
  ["Candidates", "candidate_id", "Yes", "CAND_001… unique within event", "Stable candidate identifier; randomized before model call", "Public"],
  ["Candidates", "operation_json", "Yes", "One whitelisted finite operator as JSON", "Executable repair operation", "Public"],
  ["Oracle_PRIVATE", "oracle_candidate_id", "Yes", "One READY candidate ID", "Gold repair candidate", "Private"],
  ["Oracle_PRIVATE", "evidence_spans_json", "Yes", "Non-empty JSON array", "Exact evidence spans with document IDs", "Private"],
  ["Oracle_PRIVATE", "annotator_1/2", "Yes", "Two independent annotator IDs", "Independent annotation record", "Private"],
  ["Oracle_PRIVATE", "agreement_status", "Yes", "AGREED | ADJUDICATED", "Agreement or third-party resolution", "Private"],
  ["All", "status", "Yes", "DRAFT | READY | RETIRED", "Only READY rows enter the benchmark", "Depends on sheet"],
];
dictionary.getRange(`A2:F${dictionaryRows.length + 1}`).values = dictionaryRows;

const configs = [
  { name: "Events", table: "EventsTable", end: "O31", privateSheet: false },
  { name: "Documents", table: "DocumentsTable", end: "L200", privateSheet: false },
  { name: "Candidates", table: "CandidatesTable", end: "F200", privateSheet: false },
  { name: "Oracle_PRIVATE", table: "OraclePrivateTable", end: "K31", privateSheet: true },
  { name: "DataDictionary", table: "DataDictionaryTable", end: `F${dictionaryRows.length + 1}`, privateSheet: false },
];

for (const config of configs) {
  const sheet = workbook.worksheets.getItem(config.name);
  const used = sheet.getUsedRange();
  sheet.showGridLines = false;
  sheet.freezePanes.freezeRows(1);
  sheet.freezePanes.freezeColumns(config.name === "Events" ? 1 : 0);
  used.format = {
    font: { name: "Aptos", size: 10, color: "#1F2937" },
    verticalAlignment: "top",
  };
  const header = used.getRow(0);
  header.format = {
    fill: config.privateSheet ? "#991B1B" : "#0F766E",
    font: { name: "Aptos Display", size: 10, bold: true, color: "#FFFFFF" },
    rowHeight: 28,
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "outside", style: "thin", color: "#475569" },
  };
  used.format.autofitColumns();
  used.format.autofitRows();
  used.format.borders = {
    insideHorizontal: { style: "thin", color: "#E2E8F0" },
    bottom: { style: "thin", color: "#CBD5E1" },
  };
  try {
    sheet.tables.add(used.address, true, config.table);
  } catch (_) {
    // Some renderers already expose CSV imports as a table-like range.
  }
}

const events = workbook.worksheets.getItem("Events");
events.getRange("B2:B31").dataValidation = { rule: { type: "list", values: ["dev", "test"] } };
events.getRange("C2:C31").dataValidation = { rule: { type: "list", values: [
  "TEMPORAL_VERSION", "GENERAL_RULE_EXCEPTION", "CROSS_SENTENCE_SCOPE"
] } };
events.getRange("I2:I31").dataValidation = { rule: { type: "list", values: [
  "literal_integer", "literal_string", "iri", "class"
] } };
events.getRange("N2:N31").dataValidation = { rule: { type: "list", values: ["DRAFT", "READY", "RETIRED"] } };
events.getRange("D2:H31").format.columnWidth = 22;
events.getRange("F2:F31").format.columnWidth = 42;
events.getRange("L2:M31").format.columnWidth = 32;
events.getRange("O2:O31").format.columnWidth = 28;
events.getRange("F2:F31").format.wrapText = true;

const documents = workbook.worksheets.getItem("Documents");
documents.getRange("C2:C200").dataValidation = { rule: { type: "whole", operator: "between", formula1: 0, formula2: 1000 } };
documents.getRange("K2:K200").dataValidation = { rule: { type: "list", values: ["DRAFT", "READY", "RETIRED"] } };
documents.getRange("B2:B200").format.columnWidth = 34;
documents.getRange("H2:J200").format.columnWidth = 28;
documents.getRange("L2:L200").format.columnWidth = 28;

const candidates = workbook.worksheets.getItem("Candidates");
candidates.getRange("F2:F200").dataValidation = { rule: { type: "list", values: ["DRAFT", "READY", "RETIRED"] } };
candidates.getRange("C2:C200").format.columnWidth = 38;
candidates.getRange("E2:E200").format.columnWidth = 66;
candidates.getRange("C2:E200").format.wrapText = true;

const oracle = workbook.worksheets.getItem("Oracle_PRIVATE");
oracle.getRange("I2:I31").dataValidation = { rule: { type: "list", values: ["PENDING", "AGREED", "ADJUDICATED"] } };
oracle.getRange("K2:K31").dataValidation = { rule: { type: "list", values: ["DRAFT", "READY", "RETIRED"] } };
oracle.getRange("D2:E31").format.columnWidth = 42;
oracle.getRange("J2:J31").format.columnWidth = 34;
oracle.getRange("D2:J31").format.wrapText = true;
oracle.getRange("A1:K31").format.fill = "#FEF2F2";
oracle.getRange("A1:K1").format.fill = "#991B1B";

dictionary.getRange("A2:F100").format.wrapText = true;
dictionary.getRange("A2:B100").format.columnWidth = 22;
dictionary.getRange("C2:F100").format.columnWidth = 34;

await fs.mkdir(previewDir, { recursive: true });
for (const config of configs) {
  const preview = await workbook.render({
    sheetName: config.name,
    range: config.name === "DataDictionary" ? "A1:F17" :
      config.name === "Events" ? "A1:O12" :
      config.name === "Candidates" ? "A1:F14" :
      config.name === "Oracle_PRIVATE" ? "A1:K12" : "A1:L8",
    autoCrop: "all",
    scale: 0.9,
    format: "png",
  });
  await fs.writeFile(
    path.join(previewDir, `${config.name}.png`),
    new Uint8Array(await preview.arrayBuffer()),
  );
}

const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(outputPath);
console.log(outputPath);
