from __future__ import annotations

from copy import deepcopy
from typing import Any

from rdflib import Graph, Literal, RDF, URIRef


ALLOWED_OPERATORS = {
    "REPLACE_PROPERTY_VALUE",
    "ADD_PROPERTY_VALUE",
    "REMOVE_PROPERTY_VALUE",
    "ADD_CLASS_ASSERTION",
    "REMOVE_CLASS_ASSERTION",
}


def clone_graph(source: Graph) -> Graph:
    target = Graph(identifier=source.identifier)
    for prefix, namespace in source.namespaces():
        target.bind(prefix, namespace)
    for triple in source:
        target.add(triple)
    return target


def all_uris(graph: Graph) -> set[URIRef]:
    result: set[URIRef] = set()
    for subject, predicate, obj in graph:
        for value in (subject, predicate, obj):
            if isinstance(value, URIRef):
                result.add(value)
    return result


def term_to_spec(term: URIRef | Literal) -> dict[str, str]:
    if isinstance(term, URIRef):
        return {"kind": "iri", "iri": str(term)}
    if isinstance(term, Literal):
        result = {"kind": "literal", "lexical": str(term)}
        if term.datatype:
            result["datatype"] = str(term.datatype)
        if term.language:
            result["language"] = term.language
        return result
    raise TypeError(f"不支持的RDF值类型：{type(term).__name__}")


def spec_to_term(graph: Graph, spec: dict[str, str], require_existing_iri: bool) -> URIRef | Literal:
    kind = spec.get("kind")
    if kind == "iri":
        iri_text = spec.get("iri", "").strip()
        if not iri_text:
            raise ValueError("IRI值不能为空")
        iri = URIRef(iri_text)
        if require_existing_iri and iri not in all_uris(graph):
            raise ValueError(f"拒绝使用本体中不存在的IRI：{iri}")
        return iri
    if kind == "literal":
        lexical = spec.get("lexical")
        if lexical is None:
            raise ValueError("literal缺少lexical")
        datatype = URIRef(spec["datatype"]) if spec.get("datatype") else None
        language = spec.get("language") or None
        return Literal(lexical, datatype=datatype, lang=language)
    raise ValueError(f"未知值类型：{kind}")


def operation_key(operation: dict[str, Any]) -> str:
    old_value = operation.get("old_value") or {}
    new_value = operation.get("new_value") or {}
    return "|".join([
        str(operation.get("operator", "")),
        str(operation.get("subject_iri", "")),
        str(operation.get("predicate_iri", "")),
        repr(sorted(old_value.items())),
        repr(sorted(new_value.items())),
    ])


def validate_operation_schema(operation: dict[str, Any]) -> None:
    operator = operation.get("operator")
    if operator not in ALLOWED_OPERATORS:
        raise ValueError(f"不允许的修复算子：{operator}")
    if not operation.get("subject_iri"):
        raise ValueError("修复操作缺少subject_iri")
    if operator in {"ADD_CLASS_ASSERTION", "REMOVE_CLASS_ASSERTION"}:
        if not operation.get("class_iri"):
            raise ValueError(f"{operator}缺少class_iri")
        return
    if not operation.get("predicate_iri"):
        raise ValueError(f"{operator}缺少predicate_iri")
    if operator in {"REPLACE_PROPERTY_VALUE", "REMOVE_PROPERTY_VALUE"} and not operation.get("old_value"):
        raise ValueError(f"{operator}缺少old_value")
    if operator in {"REPLACE_PROPERTY_VALUE", "ADD_PROPERTY_VALUE"} and not operation.get("new_value"):
        raise ValueError(f"{operator}缺少new_value")


def apply_operation(graph: Graph, operation: dict[str, Any]) -> None:
    """应用一个有限修复算子；新增的实体IRI必须已经存在于本体中。"""
    validate_operation_schema(operation)
    operator = operation["operator"]
    subject = URIRef(operation["subject_iri"])
    if subject not in all_uris(graph):
        raise ValueError(f"本体中不存在修复主体IRI：{subject}")

    if operator in {"ADD_CLASS_ASSERTION", "REMOVE_CLASS_ASSERTION"}:
        class_iri = URIRef(operation["class_iri"])
        if class_iri not in all_uris(graph):
            raise ValueError(f"本体中不存在类别IRI：{class_iri}")
        triple = (subject, RDF.type, class_iri)
        if operator == "REMOVE_CLASS_ASSERTION":
            if triple not in graph:
                raise ValueError(f"待删除的类别断言不存在：{triple}")
            graph.remove(triple)
        else:
            graph.add(triple)
        return

    predicate = URIRef(operation["predicate_iri"])
    if predicate not in all_uris(graph):
        raise ValueError(f"本体中不存在属性IRI：{predicate}")

    if operator in {"REPLACE_PROPERTY_VALUE", "REMOVE_PROPERTY_VALUE"}:
        old_term = spec_to_term(graph, operation["old_value"], require_existing_iri=True)
        old_triple = (subject, predicate, old_term)
        if old_triple not in graph:
            raise ValueError(f"待删除的旧断言不存在：{old_triple}")
        graph.remove(old_triple)

    if operator in {"REPLACE_PROPERTY_VALUE", "ADD_PROPERTY_VALUE"}:
        new_spec = operation["new_value"]
        new_term = spec_to_term(
            graph,
            new_spec,
            require_existing_iri=new_spec.get("kind") == "iri",
        )
        graph.add((subject, predicate, new_term))


def apply_operations(source: Graph, operations: list[dict[str, Any]]) -> Graph:
    repaired = clone_graph(source)
    for operation in operations:
        apply_operation(repaired, deepcopy(operation))
    return repaired
